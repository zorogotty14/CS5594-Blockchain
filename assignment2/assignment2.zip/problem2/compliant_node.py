from transaction import Transaction
from node import Node
from candidate import Candidate

class CompliantNode(Node):
    def __init__(self, p_graph, p_mallicious, p_txDistribution, numRound):
        self.followees = None
        self.pendingTransactions = None
        self.numRound = numRound

    def setFollowees(self, followees):
        self.followees = followees

    def setPendingTransaction(self, pendingTransactions):
        self.pendingTransactions = pendingTransactions

    def sendToFollowers(self) -> set:
        return self.pendingTransactions

    def receiveFromFollowees(self, candidates: set):
        self.pendingTransactions |= {candidate.tx for candidate in candidates}
