from transaction import Transaction
from node import Node
from candidate import Candidate
from numpy import random

class MaliciousNode(Node):
    def __init__(self, p_graph, p_mallicious, p_txDistribution, numRound):
        self._malicious_behavior = random.choice(['ignore', 'broadcast_invalid', 'change_behavior'])
        self._current_round = 0
    # YOU MAY TRY TO WRITE YOUR OWN CODE FOR MALICIOUS NODES WITH ARBITRARY BEHAVIOR TO TEST YOUR SOLUTION 
        

    def setFollowees(self, follow):
        pass
    # YOU MAY TRY TO WRITE YOUR OWN CODE FOR MALICIOUS NODES WITH ARBITRARY BEHAVIOR TO TEST YOUR SOLUTION


    def setPendingTransaction(self, pendingTransactions):
        pass
    # YOU MAY TRY TO WRITE YOUR OWN CODE FOR MALICIOUS NODES WITH ARBITRARY BEHAVIOR TO TEST YOUR SOLUTION

    def sendToFollowers(self) -> set:
        if self._malicious_behavior == 'broadcast_invalid':
            # Broadcast invalid transactions
            return {Transaction(-1)}  # Assuming -1 represents an invalid transaction
        elif self._malicious_behavior == 'change_behavior':
            # Change behavior between rounds
            if self._current_round % 2 == 0:
                return {Transaction(-1)}  # Broadcast invalid transactions in even rounds
            else:
                return set()  # Broadcast nothing in odd rounds
        else:
            return set()  # Default behavior: do nothing
    # YOU MAY TRY TO WRITE YOUR OWN CODE FOR MALICIOUS NODES WITH ARBITRARY BEHAVIOR TO TEST YOUR SOLUTION

    def receiveFromFollowees(self, candidates: set):
        if self._malicious_behavior == 'ignore':
            # Ignore incoming transactions
            pass
        else:
            # Process incoming transactions normally
            pass

            # Update current round
        self._current_round += 1
    # YOU MAY TRY TO WRITE YOUR OWN CODE FOR MALICIOUS NODES WITH ARBITRARY BEHAVIOR TO TEST YOUR SOLUTION
